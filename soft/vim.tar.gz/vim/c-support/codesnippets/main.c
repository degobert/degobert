#include <errno.h>
#include <math.h>  
#include <stdio.h> 
#include <stdlib.h>
#include <string.h>

/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  main
 *  Description:  main function
 * =====================================================================================
 */
	int
main ( int argc, char *argv[] )
{
	printf ("\nProgram %s\n\n", argv[0] );

	return EXIT_SUCCESS;
}		/* ----------  end of function main  ---------- */

